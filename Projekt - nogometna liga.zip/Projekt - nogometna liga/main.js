let imeekipe=[];
var bodovi=[];
var danigolovi=[];
var primnljenigolovi=[];
var razlikagolova=[];
var uu=0;

function funa()
{
    document.querySelector("#div2").style.display="block";
    document.querySelector("#div3").style.display="none";
}
function funb()
{
    document.querySelector("#div3").style.display="block";
    document.querySelector("#div2").style.display="none";
}
function func()
{
    let h;
    h=Number(document.getElementById("broj").value);
    /*alert(h);*/
    if(h%2==0)
    {
        if(h<11 && h>0)
        { 
            let a=220+h*87;
            document.getElementById("div4").style.height=a+"px";
            document.querySelector("#div4").style.display="block";
            for(var i=1;i<h+1;i++)
            {
                document.querySelector("#ime"+i).style.display="block";
            }
            for(var j=h+1;j<17;j++)
            {
                document.querySelector("#ime"+j).style.display="none";
            }
        }
        else{
            alert("Unesite parni broj do 10.");
            document.querySelector("#div4").style.display="none";
        }
    }
    else{
        alert("Unesite parni broj do 10.");
        document.querySelector("#div4").style.display="none";
    }
}
function fund()
{
    let h;
    document.querySelector("#div4").style.display="block";
    if(document.getElementById("r1").checked==true)
        h=4;
    else if(document.getElementById("r2").checked==true)
        h=8;
    else if(document.getElementById("r3").checked==true)
        h=16;
    else
    {
        alert("Odaberite jednu od ponuđenih opcija.");
        document.querySelector("#div4").style.display="none";
    }
    /*alert(h);*/
    let a=220+h*82;
    document.getElementById("div4").style.height=a+"px";
    for(var i=1;i<h+1;i++)
    {
        document.querySelector("#ime"+i).style.display="block";
    }
    for(var j=h+1;j<17;j++)
    {
        document.querySelector("#ime"+j).style.display="none";
    }
}
function fune()
{
    let b=0;
    let h;
    h=Number(document.getElementById("broj").value);
    for(var i=1;i<h+1;i++)
    {
        var n=document.getElementById("ime"+i).value;
        if (n.length < 1)
            b=1;
    }
    if(b==1)
        alert("Unesite imena svih ekipa.");
    else
    {
        if(document.getElementById("div2").style.display == 'block')
        {
            //window.open("liga.html",'_blank');
            /*
            var ekipa=[
               new Ekipa(document.getElementById("ime"+1).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+2).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+3).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+4).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+5).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+6).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+7).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+8).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+9).value,0,0,0,0,0,0),
               new Ekipa(document.getElementById("ime"+10).value,0,0,0,0,0,0),
            ]
            
           for(var i=1;i<2*h+1;i++)
           {
            document.getElementById("l"+i).innerHTML = ekipa[i-1].ime;
            document.getElementById("l"+i+1).innerHTML = ekipa[i].ime;
            i=i+1;
           }
           for(var i=1;i<h/2+2;i++){
           document.querySelector("#div5"+i).style.display="block";
           }*/
            let h=Number(document.getElementById("broj").value);
            let a=140+h*60;
            document.getElementById("div5").style.height=a+"px";
            for ( let i = 0; i < h; i++)
            {
                var p=0;
                imeekipe.push(document.getElementById('ime' + (i + 1)).value);
                bodovi.push(p);
                danigolovi.push(p);
                primnljenigolovi.push(p);
                razlikagolova.push(p);
            }
            for(var i=0;i<h/2;i++)
            {
            let a=2*i+1
            document.getElementById("l"+a).textContent = imeekipe[i];
            }
            for(var i=1;i<h/2+1;i++)
            {
            document.getElementById("l"+2*i).textContent = imeekipe[h-i];
            }
            for(var i=1;i<h/2+1;i++){
            document.querySelector("#div5"+i).style.display="block";
            }
            document.querySelector("#div1").style.display="none";
            document.querySelector("#div2").style.display="none";
            document.querySelector("#div3").style.display="none";
            document.querySelector("#div4").style.display="none";
            document.querySelector("#divo").style.display="none";
            document.querySelector("#div5").style.display="block";
        }
        else
        {
            let h;
            if(document.getElementById("r1").checked==true)
            h=4;
            else if(document.getElementById("r2").checked==true)
            h=8;
            document.querySelector("#div1").style.display="none";
            document.querySelector("#div2").style.display="none";
            document.querySelector("#div3").style.display="none";
            document.querySelector("#div4").style.display="none";
            document.querySelector("#divo").style.display="none";
            document.querySelector("#div10").style.display="block";
            if(h==4){
                let nn=500;
                let nm=nn+10;
                document.getElementById("t1").style.height=nn+"px";
                document.getElementById("div10").style.height=nm+"px";
            }
            if(h==8){
                document.querySelector("#dr2").style.display="block";
                document.querySelector("#t2").style.display="block";
            }

            for(var i=1;i<h+1;i++)
            {
                document.getElementById("z1"+i).textContent=document.getElementById("ime"+i).textContent;
            }

        }
            
        
    }
}
/*class Ekipa {
    constructor(ime, bodovi,pog,prg,p,n,i) {
      this.ime = ime;
      this.bodovi = bodovi;
      this.pog = pog;
      this.prg = prg;
      this.p = p;
      this.n = n;
      this.i = i;
    }
}*/



            
function funf()
{
    uu=uu+1;
    let h=Number(document.getElementById("broj").value);
    let c=0;
    var x;
    if(uu<h)
    {
    for(var i=1;i<h+1;i++)
    {
        x=Number(document.getElementById("rez"+i).value);
        if(x>-1)
        {
            c=c+1;
        }
        if((document.getElementById("rez"+i).value).length==0)
        {
           c=c-1; 
        }  
    }
    if(c==h)
    {
        /*
        if(h==4 && uu==1)
        {
            document.getElementById("l2").id="l4";
            document.getElementById("l3").id="l2";
            document.getElementById("l4").id="l3";
        }
        if(h==6 && uu==1)
        {
            document.getElementById("l3").id="l2";
            document.getElementById("l5").id="l3";
            document.getElementById("l6").id="l4";
            document.getElementById("l4").id="l5";
            document.getElementById("l2").id="l6";
        }
        if(h==8 && uu==1)
        {
            document.getElementById("l3").id="l2";
            document.getElementById("l5").id="l3";
            document.getElementById("l7").id="l4";
            document.getElementById("l8").id="l5";
            document.getElementById("l4").id="l7";
            document.getElementById("l2").id="l8";
        }
        if(h==10 && uu==1)
        {
            document.getElementById("l3").id="l2";
            document.getElementById("l5").id="l3";
            document.getElementById("l7").id="l4";
            document.getElementById("l9").id="l5";
            document.getElementById("l2").id="l10";
            document.getElementById("l4").id="l9";
            document.getElementById("l6").id="l8";
            document.getElementById("l8").id="l7";
            document.getElementById("l10").id="l6";
        }*/
        for(var i=1;i<h/2+1;i++)
        { 
            let g=2*i-1;
            let m=h-i+1;
            let l=2*i;
            let aa= document.getElementById("l"+g).textContent;
            let bb= document.getElementById("l"+l).textContent;
            let cc= Number(document.getElementById("rez"+g).value);
            let dd= Number(document.getElementById("rez"+l).value);
            utakmica(aa,bb,cc,dd);   
        }
        if(h==4)
        {
            let a=document.getElementById("l2").textContent;
            document.getElementById("l2").textContent=document.getElementById("l4").textContent;
            document.getElementById("l4").textContent=document.getElementById("l3").textContent;
            document.getElementById("l3").textContent=a;
        }
        if(h==6)
        {
            let a=document.getElementById("l2").textContent;
            document.getElementById("l2").textContent=document.getElementById("l4").textContent;
            document.getElementById("l4").textContent=document.getElementById("l6").textContent;
            document.getElementById("l6").textContent=document.getElementById("l5").textContent;
            document.getElementById("l5").textContent=document.getElementById("l3").textContent;
            document.getElementById("l3").textContent=a;
        }
        if(h==8)
        {
            let a=document.getElementById("l2").textContent;
            document.getElementById("l2").textContent=document.getElementById("l4").textContent;
            document.getElementById("l4").textContent=document.getElementById("l6").textContent;
            document.getElementById("l6").textContent=document.getElementById("l8").textContent;
            document.getElementById("l8").textContent=document.getElementById("l7").textContent;
            document.getElementById("l7").textContent=document.getElementById("l5").textContent;
            document.getElementById("l5").textContent=document.getElementById("l3").textContent;
            document.getElementById("l3").textContent=a;
        }
        if(h==10)
        {
            let a=document.getElementById("l2").textContent;
            document.getElementById("l2").textContent=document.getElementById("l4").textContent;
            document.getElementById("l4").textContent=document.getElementById("l6").textContent;
            document.getElementById("l6").textContent=document.getElementById("l8").textContent;
            document.getElementById("l8").textContent=document.getElementById("l10").textContent;
            document.getElementById("l10").textContent=document.getElementById("l9").textContent;
            document.getElementById("l9").textContent=document.getElementById("l7").textContent;
            document.getElementById("l7").textContent=document.getElementById("l5").textContent;
            document.getElementById("l5").textContent=document.getElementById("l3").textContent;
            document.getElementById("l3").textContent=a;
        }
        
        /*
        let v=document.getElementById("l"+h).textContent;
        for(var i=1;i<h-2;i++)
        {
            let f=h+1-i;
            let o=h-i;
            document.getElementById("l"+f).textContent=document.getElementById("l"+o).textContent;
        }
        document.getElementById("l2").textContent=v;
        */
       document.getElementById("lv2").textContent="TABLICA "+uu+". KOLA";
       for(var i=1;i<h+1;i++)
       {
        document.querySelector("#div6"+i).style.display="block";
       }
       let gt= h*85+320;
       document.getElementById("div7").style.height=gt+"px";
       document.querySelector("#div7").style.display="block";
       for(var i=0;i<h-1;i++)
       {
           for(var j=i+1;j<h+1;j++)
           {
               if(parseInt(bodovi[i])<parseInt(bodovi[j]))
               {
                   let w1=imeekipe[i];
                   let w2=bodovi[i];
                   let w3=danigolovi[i];
                   let w4=primnljenigolovi[i];
                   let w5=razlikagolova[i];
                   imeekipe[i]=imeekipe[j];
                   bodovi[i]=bodovi[j];
                   danigolovi[i]=danigolovi[j];
                   primnljenigolovi[i]=primnljenigolovi[j];
                   razlikagolova[i]=razlikagolova[j];
                   imeekipe[j]=w1;
                   bodovi[j]=w2;
                   danigolovi[j]=w3;
                   primnljenigolovi[j]=w4;
                   razlikagolova[j]=w5;
               }
               else if(parseInt(bodovi[i])==parseInt(bodovi[j]))
               {
                if(parseInt(razlikagolova[i])<parseInt(razlikagolova[j]))
                {
                    let w1=imeekipe[i];
                    let w2=bodovi[i];
                    let w3=danigolovi[i];
                    let w4=primnljenigolovi[i];
                    let w5=razlikagolova[i];
                    imeekipe[i]=imeekipe[j];
                    bodovi[i]=bodovi[j];
                    danigolovi[i]=danigolovi[j];
                    primnljenigolovi[i]=primnljenigolovi[j];
                    razlikagolova[i]=razlikagolova[j];
                    imeekipe[j]=w1;
                    bodovi[j]=w2;
                    danigolovi[j]=w3;
                    primnljenigolovi[j]=w4;
                    razlikagolova[j]=w5;
                }
               }
               
           }
       }
       for(var i=0;i<h;i++)
       {
           let r=i+1
           document.getElementById("p1"+r).textContent=imeekipe[i];
           document.getElementById("p2"+r).textContent=danigolovi[i];
           document.getElementById("p3"+r).textContent=primnljenigolovi[i];
           document.getElementById("p4"+r).textContent=razlikagolova[i];
           document.getElementById("p5"+r).textContent=bodovi[i];
       }
       let uk=uu+1;
        document.getElementById("lv").textContent="UNESITE REZULTATE "+uk+". KOLA";
        for(var i=1;i<h+1;i++)
        {
            document.getElementById("rez"+i).value="";
        }
    }
    else{
        alert("Unesite sve rezultate (brojeve).");
        uu=uu-1;
    }
    }
    if(uu==h-1)
    {
        for(var i=1;i<h+1;i++)
        {
        x=Number(document.getElementById("rez"+i).value);
        if(x>-1)
        {
            c=c+1;
        }
        if((document.getElementById("rez"+i).value).length==0)
        {
           c=c-1; 
        }  
        }
        if(c==h)
        {
        document.getElementById("div5").style.display="none";
        document.getElementById("lv2").textContent="KONAČNA TABLICA";
        }
        else{
        alert("Unesite sve rezultate (brojeve).");
        uu=uu-1;
    }
    }
    /*alert(uu);*/
}

 

    /*
    for ( let i = 0; i < h+1; i++) 
        imeekipe.push(document.getElementById('ime' + (i + 1)).value);
    for(var i=1;i<2*h+1;i++)
    {
     document.getElementById("l"+i).innerHTML = imeekipe[i-1];
     document.getElementById("l"+i+1).innerHTML = imeekipe[i];
     i=i+1;
    }
    for(var i=1;i<h/2+2;i++){
    document.querySelector("#div5"+i).style.display="block";*/
  

function utakmica(la,lb,r1,r2){
    let h=Number(document.getElementById("broj").value);
    if(r1>r2)
    {
        for(let i=0;i<h;i++)
        {
            if(imeekipe[i]==la)
            {
                bodovi[i]=bodovi[i]+3;
                danigolovi[i]=danigolovi[i]+r1;
                primnljenigolovi[i]=primnljenigolovi[i]+r2;
                razlikagolova[i]=razlikagolova[i]+(r1-r2);
            }
            if(imeekipe[i]==lb)
            {
                danigolovi[i]=danigolovi[i]+r2;
                primnljenigolovi[i]=primnljenigolovi[i]+r1;
                razlikagolova[i]=razlikagolova[i]+(r2-r1);
            }
        }
    }
    if(r2>r1)
    {
        for(let i=0;i<h;i++)
        {
            if(imeekipe[i]==la)
            {
                danigolovi[i]=danigolovi[i]+r1;
                primnljenigolovi[i]=primnljenigolovi[i]+r2;
                razlikagolova[i]=razlikagolova[i]+(r1-r2);
            }
            if(imeekipe[i]==lb)
            {
                bodovi[i]=bodovi[i]+3;
                danigolovi[i]=danigolovi[i]+r2;
                primnljenigolovi[i]=primnljenigolovi[i]+r1;
                razlikagolova[i]=razlikagolova[i]+(r2-r1);
            }
        }
    }
    if(r1==r2)
    {
        for(let i=0;i<h;i++)
        {
            if(imeekipe[i]==la)
            {
                bodovi[i]=bodovi[i]+1;
                danigolovi[i]=danigolovi[i]+r1;
                primnljenigolovi[i]=primnljenigolovi[i]+r2;
                razlikagolova[i]=razlikagolova[i]+(r1-r2);
            }
            if(imeekipe[i]==lb)
            {
                bodovi[i]=bodovi[i]+1;
                danigolovi[i]=danigolovi[i]+r2;
                primnljenigolovi[i]=primnljenigolovi[i]+r1;
                razlikagolova[i]=razlikagolova[i]+(r2-r1);
            }
        }
    }
}
